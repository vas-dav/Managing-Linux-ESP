#ifndef COMMON_H
#define COMMON_H

#define MIN 0
#define MAX 1
#define AMOUNT 2
#define ERROR(s) printf ("ERROR: %s\n", s);

#endif // COMMON_H
