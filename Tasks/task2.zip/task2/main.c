#include "prompt.h"
#include "random_data.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int
main (int argc, char *argv[])
{
  RANDOM_DATA *user;
  srand (time (NULL));
  user = check_args (argc, argv);
  validate_data (user);
  generate_rand_values (user);
  clean_data (user);
  return 0;
}
